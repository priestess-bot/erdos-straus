# Erdős–Straus 猜想研究知识库

本目录按时间顺序整理 Erdős–Straus 猜想的直接研究文献、关键技术依赖、
可核查数学主张和计算复现。`研究进展综述.md` 是阅读入口；`papers/`、
`claims/`、`concepts/` 中的 Markdown/YAML 文件是知识库的事实源。

当前文献快照审计至 2026-07-31；当前证明前沿和本轮旗舰命题核验至 2026-08-20。论文卡、
主张卡、概念卡及各状态的实时数量以 `python scripts/kb.py status` 和自动生成的
`index/theorem-ledger.md` 为准，不在入口文档手工复制。其中被撤回论文和存在关键证明
缺口的预印本仍会收录，但用独立状态标出。

## 当前旗舰命题（合同内核核验至 2026-08-20）

对核心素数 \(p\equiv1\pmod{24}\)，最终目标是下列双出口命题：

\[
\mathrm{F0}(p):\qquad
\mathrm{Type\ II}(p)\ \lor\ \mathrm{Type\ I\text{-}even\text{-}terminal}(p).
\]

第二出口采用已核验的 normal form：存在
\(m\equiv3\pmod4\)、\(3\le m\le p-2\)、\(x=(p+m)/4\) 及正整数 \(e,E\)，使

\[
e\mid x^2,\quad e\equiv-4^{-1}\pmod m,\quad
R=\frac{4e+1}{m},\quad K=xR-e,
\]
\[
E\mid4K^2,\quad E\equiv1\pmod R,\quad 2\mid E,\quad E\le4K-2R.
\]

这里 \(4^{-1}\) 在模 \(m\) 下取逆元。该 normal form 的代数等价性已经建立；对每个
核心素数选择 Type II 或该 Type I 证书仍是开放问题。后续主线维护下列六条可判真假的
旗舰命题：

| ID | 状态 | 核心断言 |
|---|---|---|
| T1v1 H4 clean-q closure | `CLOSED_RELATIVE` | 对 actual proper-overlap、top-capacity、\(a_{\rm alt}=1\) receipt，已验证 upstream provenance 与 priority miss 后，clean \(q\)-macro 给出书面 guard 下的 phase-local terminal 或 E1--E5 candidate；其它 H4 branch 由 T6-F2 接管。 |
| T2v1 Atomic-Admission | `CLOSED_PHASE_LOCAL` | 冻结 H4 `a=1` actual arm 与 c=8 double-low conditional arm 的有限 receipt grammar；不声称所有 c=8 parent、所有 raw path 或未来 atomic constructor 已覆盖。 |
| T3v1 Mark Invariant | `CLOSED_CURRENT_GRAPH` | initializer 与当前 15 个 registered edge generators 均不产生 nontrivial mark，故冻结具名图中该 family 不可达；新增 marked constructor 会自动重开义务。 |
| T4v1 Fresh-G-Handoff | `CLOSED_RELATIVE` | ordinary \(q\ge1\) G endpoint 在书面 guard 下进入 target-independent full-carrier fresh root 并完成首条严格 segment；post-handoff Type I totality 仍属 T6-F2。 |
| T5v1 Well-Founded Admission | `CLOSED_CONTRACT_LEVEL` | 所有合同认可的 `verified_edge` 都携带固定 ticket，并严格降低 \(\mathbb N^7\) 势；不推出每个非终端状态都存在 edge。 |
| T6 Global-Selector | `OPEN` | 确定性 selector 在每个核心 prime / actual reachable legal state 输出 terminal 或一条可提升、严格下降的 verified edge。 |

这些编号现在指向冻结的 pre-T6 合同内核。历史强版本 `T1*--T3*` 不再与已闭合的
v1 命题共用状态：未覆盖的 H4、raw atomic 和 future mark 量词分别由 T6 的 family-totality、
reachable-state exhaustion 与 constructor admission firewall 接管。精确迁移和 closed-world
证明见 [`docs/pre-T6-contract-kernel-closure-2026-08-20.md`](docs/pre-T6-contract-kernel-closure-2026-08-20.md)，
机器事实源见 [`data/pre-t6-contract-kernel-v1.json`](data/pre-t6-contract-kernel-v1.json)。

六条命题的历史推导、证据和反证标准仍见
[`concepts/flagship-proof-program-2026-08-16.md`](concepts/flagship-proof-program-2026-08-16.md)。
T1v1 与 T4v1 都只是限定输入域的相对闭包；T2v1 是有限 grammar；T3v1 是冻结图不变量；
T5v1 只提供 edge-admission 良基性。它们都不提供 selector totality。T4 的独立冻结证明包复核见
[`docs/q1-fresh-handoff-proof-package-audit-2026-08-17.md`](docs/q1-fresh-handoff-proof-package-audit-2026-08-17.md)；
T2/T5 的本次合并边界见
[`docs/T2-T5-full-integration-review-2026-08-17.md`](docs/T2-T5-full-integration-review-2026-08-17.md)。
当前 named graph 的 T2/T3 reachability 边界见
[`docs/T6-actual-reachable-coverage-audit-2026-08-17.md`](docs/T6-actual-reachable-coverage-audit-2026-08-17.md)。
本轮 T6 全闭合尝试、新增子定理与仍缺量词见
[`docs/T6-closure-attempt-audit-2026-08-17.md`](docs/T6-closure-attempt-audit-2026-08-17.md)。

### T6 近期进展截面与证明边界（2026-08-20）

T6 仍为 `OPEN`。已闭合的完整局部 selector 项是每个核心素数的规范初始状态 serializer：
取 \(q=1\)、\(m=3\)、\(X=(p+3)/4\)，若 \(X\) 有 \(2\pmod3\) 的素因子则给出
直接 Type II terminal；否则得到 ordinary G receipt，并进入既有 full-carrier
Type I handoff。该分派只闭合初始根，不声称 handoff 后的 Type I 路径 total。

本次还机械闭合了冻结 transition surface 的 inventory、当前图 nontrivial-mark unreachability
以及 future atomic/marked constructor 的 admission firewall。后者把原 O4 从一个悬空流程
缺口改为“未补 T2/T3、serializer、lift 和 T6 owner 就拒绝合并”的可执行规则；它只对冻结
v1 有效，新增构造器时自动重开。

本轮进一步收缩了 proper-root \(m=3\)、\(q=5\) rank-stutter 子分支。对其中的实际
raw occurrence，现有确定性策略至多消费两个因子即可到达 p-free primitive node；full-capacity
支若非 terminal 则只剩 single-side bundle。重算 canonical complete-excess support 后，
新的重复 \(a=1\) hard branch 被压缩为


\[
L_\omega\equiv1\pmod{p^2}.
\]

这消除了 p-block 作为必要 raw-policy 分支，也将 companion 的未分类算术压缩为规范
complete-excess 重算；但尚未提供连续的 E1--E4 receipt 或全称 QC1/TR1 exit。因此它不是
T6、O2 或全局 selector 的闭合结论。

精确的冻结 family/edge 清单、立即闭合项和五个剩余 frontier theorem 见
[`data/t6-proof-frontier-v2.json`](data/t6-proof-frontier-v2.json) 与
[`docs/T6-proof-boundary-2026-08-20.md`](docs/T6-proof-boundary-2026-08-20.md)。原始 acceptance-gate
账本仍保留在 [`data/t6-selector-obligation-ledger-v1.json`](data/t6-selector-obligation-ledger-v1.json)；
v2 不删除其中任何数学 gap，只把 O4 流程义务改造成 admission firewall，并把其余八项唯一
映射到 F1--F3。该 p-free policy 及其 \(p^2\) canonical gate 的完整推导见
[`claims/type-I-root-capacity-stutter-m-three-biquadratic-norm-reduction.md`](claims/type-I-root-capacity-stutter-m-three-biquadratic-norm-reduction.md)
和 [`docs/T6-current-progress-2026-08-17.md`](docs/T6-current-progress-2026-08-17.md)。

## 快速使用

```bash
python scripts/kb.py validate
python scripts/kb.py build
python scripts/kb.py search "half dimensional sieve"
python scripts/kb.py status
python reproductions/pre_t6_contract_kernel_audit.py --root .
python -m unittest tests.test_pre_t6_contract_kernel_audit -v
```

`build` 生成：

- `index/timeline.md`：按首次公开日期排列的完整文献时间线；
- `index/citation-graph.mmd`：论文引用图；
- `index/theorem-ledger.md`：从主张卡自动生成的数学状态、证明来源与审阅状态账本；
- `index/catalog.json`：供其他工具消费的结构化目录；
- `index/kb.sqlite`：带 FTS5 全文检索的 SQLite 数据库。

主张卡用三个互不替代的字段记录证据状态：`claim_status` 表示数学结论状态；
可选的 `proof_provenance` 表示证明或证据来自原始文献、仓库推导、计算复现或混合来源；
可选的 `review_status` 表示卡片中的论证是否经过仓库内、独立或外部复核。旧卡缺少后两个
字段仍然有效，构建时统一显示为 `unspecified`，不会从 `claim_status` 自动推断。允许值见
`schemas/document-types.yaml`；新卡从 `templates/claim-note.md` 创建并应主动填写。

`proof_provenance` 的语义为：`external_primary_source` 指精确陈述和证明锚定到所列原始
来源，`repository_derivation` 指证明写在本仓库，`computational_reproduction` 指证据来自
可复现程序和产物，`mixed` 指结论实质依赖多类证据，`not_applicable` 用于未声称已有证明
的开放问题等，`unspecified` 表示尚未完成分类。`review_status` 中，`unreviewed` 表示没有
记录第二轮复核，`internal_review` 表示完成仓库内复核，`independent_review` 表示存在独立
证明或独立实现的复核，`external_review` 表示存在仓库外审阅记录；后三者应在卡片正文给出
可核查锚点，`unspecified` 只表示尚未分类。

研究方法、已确立结论和逐点证明缺口的历史导航见
[`concepts/research-directions-and-proof-gap.md`](concepts/research-directions-and-proof-gap.md)；
当前证明前沿、下一阶段目标及其依赖顺序见
[`concepts/current-frontier-2026-07-29.md`](concepts/current-frontier-2026-07-29.md)。

常用检索过滤器：

```bash
python scripts/kb.py search "parametrization" --type paper --year-from 2010
python scripts/kb.py search "计算验证" --type claim --tag computation
```

公开副本由 `python scripts/kb.py publish` 生成到 `public/`。该命令不会复制
内部工作日志、原始来源文件或标记为 `visibility: internal` 的文档；发布前还会扫描
内部检索标记和本机路径。公开版包含候选文献清单、BibTeX 和小尺度复现材料。

## 增量研究流程

1. 把新发现写入 `bibliography/candidates.yaml`，先作纳入、归并或排除判断。
2. 对纳入论文建立 `papers/<citation_key>.md`，分别记录出版状态与数学核查状态。
3. 将可复用结论拆成 `claims/`，将术语和方法拆成 `concepts/`。
4. 运行 `validate`、测试、`build` 和 `publish`；检索日期与未取得原文的缺口写入
   `bibliography/search-log.md`。

有限复现入口为 `python reproductions/esc_reproduce.py`。它核对经典恒等式、模
840 残余类、因子对证书和 Bradford 的 Type I/II 除子对应，不是对已报告
`10^17` 或 `10^18` 搜索的全量复现。

`python reproductions/short_certificate.py` 另行按 \(m=4x-p\) 搜索 Type I/II
的最小首分母缺口，用于检验“短证书或递降”研究计划中的候选短界；它同样是
有限实验。

## 证据纪律

- 同行评议状态与数学核查状态分别记录。
- 每个实质性主张必须指向原始论文及页码、定理号或公式号。
- 预印本、计算报告、启发式和存在关键缺口的证明声称不能混写。
- 未取得原文时明确标记，不以二手摘要冒充精读。
- “文献全集”是带截止日期的可审计语料，不声称永久穷尽。

本知识库使用 AI 辅助进行检索、格式化、代码实现和初步数学核查。最终数学
结论以链接的原始文献为准，争议性结论保留明确的核查状态与限制说明。
